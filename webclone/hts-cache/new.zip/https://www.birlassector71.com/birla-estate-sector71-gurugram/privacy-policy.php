 <!DOCTYPE html>
<html lang="en">
<head>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WMFHKLP3');</script>
<!-- End Google Tag Manager -->

             <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        
        <link rel="icon" type="image/x-icon" href="favicon.png"  />
        <title>Birla Sector 71 - 3 & 3.5 BHK Luxury Apartments in Gurugram </title>
        <link rel="preload" href="./assets/img/mobl.webp" as="image"> 
        <link rel="stylesheet" href="./assets/css/pure_style.css" />
        <link rel="preload" href="./assets/css/pure_style.css" as="style" />
        <link rel="preload" href="./assets/fonts/micon.woff2" as="font" type="font/woff2" crossorigin />
        <link rel="dns-prefetch" href="//google-analytics.com" crossorigin />
        <link rel="dns-prefetch" href="//googletagmanager.com" crossorigin />
        <link rel="dns-prefetch" href="//www.googleadservices.com" crossorigin />
        <link rel="dns-prefetch" href="//googleads.g.doubleclick.net" crossorigin />
        <meta name="description" content=" Birla Sector 71 offering 3 & 3.5 BHK luxury apartments in Gurugram. Check property prices, floor plans & amenities.  "/>
        <meta name="keywords" content=""/>
        <link rel="canonical" href="https://www.birlassector71.com/birla-estate-sector71-gurugram/" />
        <meta property="og:title" content="Birla Sector 71 - 3 & 3.5 BHK Luxury Apartments in Gurugram " />
        <meta property="og:type" content="https://www.birlassector71.com/birla-estate-sector71-gurugram/" />
        <meta property="og:url" content="https://www.birlassector71.com/birla-estate-sector71-gurugram/" />
        <meta property="og:image" content="./assets/img/desktb1.webp" />
        <meta property="og:description" content=" Birla Sector 71 offering 3 & 3.5 BHK luxury apartments in Gurugram. Check property prices, floor plans & amenities.  " />
        <meta property="twitter:title" content="Birla Sector 71 - 3 & 3.5 BHK Luxury Apartments in Gurugram " />
        <meta property="twitter:description" content=" Birla Sector 71 offering 3 & 3.5 BHK luxury apartments in Gurugram. Check property prices, floor plans & amenities.  " />
        <meta property="twitter:card" content="summary_large_image" />
        <style>
            :root {--colorPrimary: #840d70;--colorSecondary: #003f64; --colorBtn: #ffffff;--bgDesk: url('../img/desktb1.webp');--bgMob: url('../img/mobl.webp');
}
            @font-face { font-family: 'Roboto'; src: url('./assets/fonts/Roboto-Regular.woff2') format('woff2'); font-weight: normal; }
            @font-face {font-family: 'Roboto'; src: url('./assets/fonts/Roboto-Bold.woff2') format('woff2'); font-weight: bold; }
            #loader {width: 100vw;height: 100vh;background-color: rgba(255, 255, 255, 1);position: fixed;top: 0;left: 0;z-index: 1040;}
            .loader-text {display: block;text-align: center;color: #d7d7d7;font-family: Roboto, sans-serif;position: absolute;top: 50%;left: 50%;-webkit-transform: translate(-50%, -50%);-moz-transform: translate(-50%, -50%);-ms-transform: translate(-50%, -50%);-o-transform: translate(-50%, -50%);transform: translate(-50%, -50%);}
            @keyframes loader {
                0% {filter: grayscale(0);}
                50% {filter: grayscale(100%);}
                100% {filter: grayscale(0);}}
            /*.loader-logo {width: 300px;-webkit-animation: loader 1.3s infinite linear;-moz-animation: loader 1.3s infinite linear;-ms-animation: loader 1.3s infinite linear;-o-animation: loader 1.3s infinite linear;animation: loader 1.3s infinite linear;}*/
            /*.pload {display: none;}*/
            .iti__flag-container {display: none;}
            section#mymap {height: 540px;}
            button.btn.btn-sm.btn-outline-info.sectio-bro-btn.overflow-hidden.enqModal {margin-bottom: 15px;}
            input#submitBtn {margin: 15px 0;}
            .textcolor{color:#fff;}
            button.btn.btn-info.micro-form-btn.effetMoveGradient.submitBtn.enqModal {margin-bottom: 15px;}
            a.drift-open-chat {color: #fff;}
            p{text-align: justify;}
            select.my_country_name.form-control.rounded-0.micro-form-field {float: left;display: inline-block;width: 40%;padding-left: 8px;}
            input#modal_my_mobile {width: 60%;}
            /*--for thank you page --*/
            .thankyou-text p {text-align: center !important;}
        </style>
        <!-- Small Chatbot -->
        
        <link rel="stylesheet" href="./assets/css/chatv25.css" />

<!-- Small Chatbot -->
<div class="chat-pop-sm">
    <button id="chat-pop-sm-close" type="button" class="close" data-dismiss="chat-pop-sm" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
    <div class="chat-pop-txt">
        “Hey, I'm Pooja Agarwal!“ <strong>How can I help you?</strong>
    </div>
    <button class="chat-pop-sm-btn openchat" type="button" id="chat-square-small">Let's Chat</button>
</div>
<!-- Small Chatbot -->

<!-- Chatbot -->
<div id="chat-square" class="btn"></div>
<div id="chat-close" class="btn chat-box-toggle">
    <div class="close-img"></div>
</div>

<div class="chat-wrapper">
    <div class="chat-header">
        <div class="chat-header-photo">
            <span class="active-circle"></span>
        </div>
        <div class="chat-header-name">Pooja Agarwal</div>
    </div>

    <div class="chat-box-body">
        <div class="chat-box-overlay"></div>
        <div class="chat-logs">
            <div id="hb-chat-bot">
                <div class="chat-container">
                    <div class="chat-messages-time"></div>
                    <div class="chat-messages-container"></div>
                    <div class="chat-actions-container"></div>
                    <div class="chat-footer"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Chatbot -->

        <!-- Chatbot -->
    </head>
    <body data-spy="scroll" data-target="#navbarNav">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WMFHKLP3"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

      <header class="micro-nav fixed-top pload">
            <nav class="navbar navbar-expand-lg navbar-light bg-white micro-navbar">
                <a class="navbar-brand" href="/birla-estate-sector71-gurugram/" ><img alt="Birla Sector 71 Gurgaon Logo" src="./assets/img/logo.svg" class="logo" /></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav nav-fill">
                        <li class="nav-item"><a class="nav-link" href="#home"><i class="mi mi-home nav-icon"></i><span class="d-sm-inline d-md-none"> Home</span></a></li>
                        <li class="nav-item"><a class="nav-link" href="#pricing"><i class="mi mi-price nav-icon"></i> Price</a></li>
                        <li class="nav-item"><a class="nav-link" href="#sitefloorplan"><i class="mi mi-siteplan nav-icon"></i> Site &amp; Floor Plan</a></li>
                        <li class="nav-item"><a class="nav-link" href="#amenities"><i class="mi mi-ami nav-icon"></i> Amenities</a></li>
                        <li class="nav-item"><a class="nav-link" href="#gallery"><i class="mi mi-gallery nav-icon"></i> Gallery</a></li>
                        <li class="nav-item"><a class="nav-link" href="#address_section"><i class="mi mi-location nav-icon"></i> Location</a></li>
                        <li class="nav-item"><a class="nav-link" href="#sitevisit"><i class="mi mi-sitevisit nav-icon"></i> Virtual Site Visit </a></li>
<li class="nav-item overflow-hidden"><a class="nav-link enqModal" href="#" data-form="md" data-title="Download brochure" data-btn="Download now" data-enquiry="Download Brochure Toolbar" data-redirect="brochure" data-redirect-file="brochure.pdf" data-toggle="modal" data-target="#enqModal" > <i class="mi mi-download nav-icon d-inline-block animated slideInDown infinite"></i> Download Brochure </a> </li> </ul>
                </div>
            </nav>
        </header>
<main class="pload">
 <!--<style>-->
 <!--    section{-->
 <!--        height: 100vh;-->
 <!--    }-->
 <!--</style>-->
  <section class="section shadow-sm lazyload" id="developer">
    <div class="thankyou-text">
<p><br><br>
<b>Privacy Policies</b><hr><br>
This website is not the official one; it is only meant to be used for informative purposes. In our commitment to safeguarding your personal information, we have formulated this comprehensive privacy policy to protect your interests and data on our website.
<br><br>
<!--<b>Privacy Policy</b><br><br>-->
<!--This website is not the official one; it is only meant to be used for informative purposes. In our commitment to safeguarding your personal information, we have formulated this comprehensive privacy policy to protect your interests and data on our website.-->
<!--<br><br>-->
<b>Update of Privacy Policy</b><br><br>
This privacy policy is open to revision and review at any time, without notification or consent. Therefore, please re-visit the website and regularly go through the terms and conditions of this privacy policy to stay informed about the modifications that have been made.
<br><br>
<b>User Information</b><br><br>
By accessing our website, you accept our terms and give permission for us to collect and use any information you voluntarily submit. While certain visits might not require personal information, others could in order to provide access to particular links or websites. We use the information you have given us to deliver information and updates, confirm receipt of your message, and offer pertinent goods and services. We do not share personal information with outside parties, and you have the option to unsubscribe from our email list.
<br><br>
<b>Security</b><br><br>
Sensitive information is encrypted during transmission between the client and server. We restrict employee access to your personal information and hold them to high levels of confidentiality. We may use cookies for security, session continuity, and customization purposes. Rejecting cookies may limit your access to certain services or features.

For questions or suggestions regarding this privacy statement or your dealings with this website, please contact us.

This website is not the official one; it is only meant to be used for informative purposes.
<br><br>

</p>
    </div>
</section>
    

</main>

<style>
.action-icon img{ height: 22px; width: auto; margin-right: 7px; }
.ft-main{ display:flex; justify-content:center; align-items:center; width:100%; padding:0% 2%; font-size:14px; }
.ft-left{ width:82%; }
.ft-right{ width:16%; }
.acceptcookies{ font-size: 16px; padding: 3px 30px; }
@media (min-width: 1920px) and (max-width: 2560px)  {
    .ft-main{ font-size:19px; }
    }
@media (min-width: 2561px) and (max-width: 5120px)  {
    .ft-main{ font-size:36px; }
    }
@media (min-width: 1920px) and (max-width: 5120px)  {
    .acceptcookies{ font-size: 46px; padding: 3px 30px; }
    }
@media (min-width: 320px) and (max-width: 767px)  {
    .ft-main{ display:block; }
    .ft-left{ width:100%; text-align:justify; }
    .ft-right{ width:100%; }
    .acceptcookies{ margin-top: 10px; margin-left:0px!important; }
     }
</style>
     <!--exit modal 1 start -->
     <div class="modal fade lightbox" id="enqModal233"  role="dialog" aria-hidden="true"></div>
     <!--Exit modal 1 end-->
     <!--exit modal 2 start -->
     <div class="modal fade lightbox2 abc"></div> 
    <!--exit modal 2 end -->
            <div class="micro-side text-center">
                <div class="og-section pb-2">
                    <ul class="nav nav-fill og-block">
                        <li class="new-pdf nav-item enqModal" data-form="lg" data-title="Download Price Sheet" data-btn="Download Now" data-enquiry="Download Price Sheet Top Corner Desktop" data-toggle="modal" data-target="#enqModal"><div><img src="assets/img/newpdfimg.png" class="bounce pdf-img"></div><div>Download<br>Price Sheet</div></li>
                        <li class="nav-item driftc d-flex-center-items"> <a href="tel:+912246181156" class="textcolor d-flex-center-items"><i class="mi mi-call"></i> +912246181156</a></li>   
                    </ul>
                    <button
                        class="btn-danger pulse-shadow btn btn-sm btn-info micro-form-btn-sm effectScale enqModal mt-1"
                        data-form="sm"
                        data-title="Instant Call Back"
                        data-btn="Request Call Now"
                        data-enquiry="Request Call Back"
                        data-toggle="modal"
                        data-target="#enqModal"
                    >
                        <span class="mi mi-call action-icon"></span> Instant Call Back</button>
                </div>
                <span class="d-block form-heading font-weight-bold mr-tb-text">Get The Best Quote</span>
                <form action="https://microsite.fanmrealty.com/live/lead-callback-v25.php" method="post" class="form-side" id="pardotForm" class="pardotForm">
                    <input type="text" id="fname" placeholder="Name" name="fname" class="form-control rounded-0 micro-form-field" required>
                    <div class="error" id="name_error"></div>
                    <input type="email" id="email" placeholder="Email Address(Optional)" name="email" class="form-control rounded-0 micro-form-field">
                    <div class="error" id="address_error"></div>
                    <select class="my_country_name form-control rounded-0 micro-form-field" aria-label="countryname" name="country_name">
                        <option data-countrycode="IN" value="India" data-contry_code="91">India (+91)</option>
                        <option data-countrycode="AF" value="Afghanistan" data-contry_code="93">Afghanistan (+93)</option>
                        <option data-countrycode="AL" value="Albania" data-contry_code="355">Albania (+355)</option>
                        <option data-countrycode="DZ" value="Algeria" data-contry_code="213">Algeria (+213)</option>
                        <option data-countrycode="AS" value="American Samoa" data-contry_code="1-684">American Samoa (+1-684)</option>
                        <option data-countrycode="AD" value="Andorra" data-contry_code="376">Andorra (+376)</option>
                        <option data-countrycode="AO" value="Angola" data-contry_code="244">Angola (+244)</option>
                        <option data-countrycode="AI" value="Anguilla" data-contry_code="1-264">Anguilla (+1-264)</option>
                        <option data-countrycode="AQ" value="Antarctica" data-contry_code="672">Antarctica (+672)</option>
                        <option data-countrycode="AG" value="Antigua and Barbuda" data-contry_code="1-268">Antigua and Barbuda (+1-268)</option>
                        <option data-countrycode="AR" value="Argentina" data-contry_code="54">Argentina (+54)</option>
                        <option data-countrycode="AM" value="Armenia" data-contry_code="374">Armenia (+374)</option>
                        <option data-countrycode="AW" value="Aruba" data-contry_code="297">Aruba (+297)</option>
                        <option data-countrycode="AU" value="Australia" data-contry_code="61">Australia (+61)</option>
                        <option data-countrycode="AT" value="Austria" data-contry_code="43">Austria (+43)</option>
                        <option data-countrycode="AZ" value="Azerbaijan" data-contry_code="994">Azerbaijan (+994)</option>
                        <option data-countrycode="BS" value="Bahamas" data-contry_code="1-242">Bahamas (+1-242)</option>
                        <option data-countrycode="BH" value="Bahrain" data-contry_code="973">Bahrain (+973)</option>
                        <option data-countrycode="BD" value="Bangladesh" data-contry_code="880">Bangladesh (+880)</option>
                        <option data-countrycode="BB" value="Barbados" data-contry_code="1-246">Barbados (+1-246)</option>
                        <option data-countrycode="BY" value="Belarus" data-contry_code="375">Belarus (+375)</option>
                        <option data-countrycode="BE" value="Belgium" data-contry_code="32">Belgium (+32)</option>
                        <option data-countrycode="BZ" value="Belize" data-contry_code="501">Belize (+501)</option>
                        <option data-countrycode="BJ" value="Benin" data-contry_code="229">Benin (+229)</option>
                        <option data-countrycode="BM" value="Bermuda" data-contry_code="1-441">Bermuda (+1-441)</option>
                        <option data-countrycode="BT" value="Bhutan" data-contry_code="975">Bhutan (+975)</option>
                        <option data-countrycode="BO" value="Bolivia" data-contry_code="591">Bolivia (+591)</option>
                        <option data-countrycode="BA" value="Bosnia and Herzegowina" data-contry_code="387">Bosnia and Herzegowina (+387)</option>
                        <option data-countrycode="BW" value="Botswana" data-contry_code="267">Botswana (+267)</option>
                        <option data-countrycode="BV" value="Bouvet Island" data-contry_code="47">Bouvet Island (+47)</option>
                        <option data-countrycode="BR" value="Brazil" data-contry_code="55">Brazil (+55)</option>
                        <option data-countrycode="IO" value="British Indian Ocean Territory" data-contry_code="246">British Indian Ocean Territory (+246)</option>
                        <option data-countrycode="BN" value="Brunei Darussalam" data-contry_code="673">Brunei Darussalam (+673)</option>
                        <option data-countrycode="BG" value="Bulgaria" data-contry_code="359">Bulgaria (+359)</option>
                        <option data-countrycode="BF" value="Burkina Faso" data-contry_code="226">Burkina Faso (+226)</option>
                        <option data-countrycode="BI" value="Burundi" data-contry_code="257">Burundi (+257)</option>
                        <option data-countrycode="KH" value="Cambodia" data-contry_code="855">Cambodia (+855)</option>
                        <option data-countrycode="CM" value="Cameroon" data-contry_code="237">Cameroon (+237)</option>
                        <option data-countrycode="CA" value="Canada" data-contry_code="1">Canada (+1)</option>
                        <option data-countrycode="CV" value="Cape Verde" data-contry_code="238">Cape Verde (+238)</option>
                        <option data-countrycode="KY" value="Cayman Islands" data-contry_code="1-345">Cayman Islands (+1-345)</option>
                        <option data-countrycode="CF" value="Central African Republic" data-contry_code="236">Central African Republic (+236)</option>
                        <option data-countrycode="TD" value="Chad" data-contry_code="235">Chad (+235)</option>
                        <option data-countrycode="CL" value="Chile" data-contry_code="56">Chile (+56)</option>
                        <option data-countrycode="CN" value="China" data-contry_code="86">China (+86)</option>
                        <option data-countrycode="CX" value="Christmas Island" data-contry_code="61">Christmas Island (+61)</option>
                        <option data-countrycode="CC" value="Cocos (Keeling) Islands" data-contry_code="61">Cocos (Keeling) Islands (+61)</option>
                        <option data-countrycode="CO" value="Colombia" data-contry_code="57">Colombia (+57)</option>
                        <option data-countrycode="KM" value="Comoros" data-contry_code="269">Comoros (+269)</option>
                        <option data-countrycode="CG" value="Congo Democratic Republic of" data-contry_code="242">Congo Democratic Republic of (+242)</option>
                        <option data-countrycode="CK" value="Cook Islands" data-contry_code="682">Cook Islands (+682)</option>
                        <option data-countrycode="CR" value="Costa Rica" data-contry_code="506">Costa Rica (+506)</option>
                        <option data-countrycode="CI" value="Cote D'Ivoire" data-contry_code="225">Cote D'Ivoire (+225)</option>
                        <option data-countrycode="HR" value="Croatia" data-contry_code="385">Croatia (+385)</option>
                        <option data-countrycode="CU" value="Cuba" data-contry_code="53">Cuba (+53)</option>
                        <option data-countrycode="CY" value="Cyprus" data-contry_code="357">Cyprus (+357)</option>
                        <option data-countrycode="CZ" value="Czech Republic" data-contry_code="420">Czech Republic (+420)</option>
                        <option data-countrycode="DK" value="Denmark" data-contry_code="45">Denmark (+45)</option>
                        <option data-countrycode="DJ" value="Djibouti" data-contry_code="253">Djibouti (+253)</option>
                        <option data-countrycode="DM" value="Dominica" data-contry_code="1-767">Dominica (+1-767)</option>
                        <option data-countrycode="DO" value="Dominican Republic" data-contry_code="1-809">Dominican Republic (+1-809)</option>
                        <option data-countrycode="TL" value="Timor-Leste" data-contry_code="670">Timor-Leste (+670)</option>
                        <option data-countrycode="EC" value="Ecuador" data-contry_code="593">Ecuador (+593)</option>
                        <option data-countrycode="EG" value="Egypt" data-contry_code="20">Egypt (+20)</option>
                        <option data-countrycode="SV" value="El Salvador" data-contry_code="503">El Salvador (+503)</option>
                        <option data-countrycode="GQ" value="Equatorial Guinea" data-contry_code="240">Equatorial Guinea (+240)</option>
                        <option data-countrycode="ER" value="Eritrea" data-contry_code="291">Eritrea (+291)</option>
                        <option data-countrycode="EE" value="Estonia" data-contry_code="372">Estonia (+372)</option>
                        <option data-countrycode="ET" value="Ethiopia" data-contry_code="251">Ethiopia (+251)</option>
                        <option data-countrycode="FK" value="Falkland Islands (Malvinas)" data-contry_code="500">Falkland Islands (Malvinas) (+500)</option>
                        <option data-countrycode="FO" value="Faroe Islands" data-contry_code="298">Faroe Islands (+298)</option>
                        <option data-countrycode="FJ" value="Fiji" data-contry_code="679">Fiji (+679)</option>
                        <option data-countrycode="FI" value="Finland" data-contry_code="358">Finland (+358)</option>
                        <option data-countrycode="FR" value="France" data-contry_code="33">France (+33)</option>
                        <option data-countrycode="GF" value="French Guiana" data-contry_code="594">French Guiana (+594)</option>
                        <option data-countrycode="PF" value="French Polynesia" data-contry_code="689">French Polynesia (+689)</option>
                        <option data-countrycode="GA" value="Gabon" data-contry_code="241">Gabon (+241)</option>
                        <option data-countrycode="GM" value="Gambia" data-contry_code="220">Gambia (+220)</option>
                        <option data-countrycode="GE" value="Georgia" data-contry_code="995">Georgia (+995)</option>
                        <option data-countrycode="DE" value="Germany" data-contry_code="49">Germany (+49)</option>
                        <option data-countrycode="GH" value="Ghana" data-contry_code="233">Ghana (+233)</option>
                        <option data-countrycode="GI" value="Gibraltar" data-contry_code="350">Gibraltar (+350)</option>
                        <option data-countrycode="GR" value="Greece" data-contry_code="30">Greece (+30)</option>
                        <option data-countrycode="GL" value="Greenland" data-contry_code="299">Greenland (+299)</option>
                        <option data-countrycode="GD" value="Grenada" data-contry_code="1-473">Grenada (+1-473)</option>
                        <option data-countrycode="GP" value="Guadeloupe" data-contry_code="590">Guadeloupe (+590)</option>
                        <option data-countrycode="GU" value="Guam" data-contry_code="1-671">Guam (+1-671)</option>
                        <option data-countrycode="GT" value="Guatemala" data-contry_code="502">Guatemala (+502)</option>
                        <option data-countrycode="GN" value="Guinea" data-contry_code="224">Guinea (+224)</option>
                        <option data-countrycode="GW" value="Guinea-bissau" data-contry_code="245">Guinea-bissau (+245)</option>
                        <option data-countrycode="GY" value="Guyana" data-contry_code="592">Guyana (+592)</option>
                        <option data-countrycode="HT" value="Haiti" data-contry_code="509">Haiti (+509)</option>
                        <option data-countrycode="HM" value="Heard Island and McDonald Islands" data-contry_code="011">Heard Island and McDonald Islands (+011)</option>
                        <option data-countrycode="HN" value="Honduras" data-contry_code="504">Honduras (+504)</option>
                        <option data-countrycode="HK" value="Hong Kong" data-contry_code="852">Hong Kong (+852)</option>
                        <option data-countrycode="HU" value="Hungary" data-contry_code="36">Hungary (+36)</option>
                        <option data-countrycode="IS" value="Iceland" data-contry_code="354">Iceland (+354)</option>
                        <option data-countrycode="IN" value="India" data-contry_code="91" selected="">India (+91)</option>
                        <option data-countrycode="ID" value="Indonesia" data-contry_code="62">Indonesia (+62)</option>
                        <option data-countrycode="IR" value="Iran (Islamic Republic of)" data-contry_code="98">Iran (Islamic Republic of) (+98)</option>
                        <option data-countrycode="IQ" value="Iraq" data-contry_code="964">Iraq (+964)</option>
                        <option data-countrycode="IE" value="Ireland" data-contry_code="353">Ireland (+353)</option>
                        <option data-countrycode="IL" value="Israel" data-contry_code="972">Israel (+972)</option>
                        <option data-countrycode="IT" value="Italy" data-contry_code="39">Italy (+39)</option>
                        <option data-countrycode="JM" value="Jamaica" data-contry_code="1-876">Jamaica (+1-876)</option>
                        <option data-countrycode="JP" value="Japan" data-contry_code="81">Japan (+81)</option>
                        <option data-countrycode="JO" value="Jordan" data-contry_code="962">Jordan (+962)</option>
                        <option data-countrycode="KZ" value="Kazakhstan" data-contry_code="7">Kazakhstan (+7)</option>
                        <option data-countrycode="KE" value="Kenya" data-contry_code="254">Kenya (+254)</option>
                        <option data-countrycode="KI" value="Kiribati" data-contry_code="686">Kiribati (+686)</option>
                        <option data-countrycode="KP" value="Korea, Democratic People's Republic of" data-contry_code="850">Korea, Democratic People's Republic of (+850)</option>
                        <option data-countrycode="KR" value="South Korea" data-contry_code="82">South Korea (+82)</option>
                        <option data-countrycode="KW" value="Kuwait" data-contry_code="965">Kuwait (+965)</option>
                        <option data-countrycode="KG" value="Kyrgyzstan" data-contry_code="996">Kyrgyzstan (+996)</option>
                        <option data-countrycode="LA" value="Lao People's Democratic Republic" data-contry_code="856">Lao People's Democratic Republic (+856)</option>
                        <option data-countrycode="LV" value="Latvia" data-contry_code="371">Latvia (+371)</option>
                        <option data-countrycode="LB" value="Lebanon" data-contry_code="961">Lebanon (+961)</option>
                        <option data-countrycode="LS" value="Lesotho" data-contry_code="266">Lesotho (+266)</option>
                        <option data-countrycode="LR" value="Liberia" data-contry_code="231">Liberia (+231)</option>
                        <option data-countrycode="LY" value="Libya" data-contry_code="218">Libya (+218)</option>
                        <option data-countrycode="LI" value="Liechtenstein" data-contry_code="423">Liechtenstein (+423)</option>
                        <option data-countrycode="LT" value="Lithuania" data-contry_code="370">Lithuania (+370)</option>
                        <option data-countrycode="LU" value="Luxembourg" data-contry_code="352">Luxembourg (+352)</option>
                        <option data-countrycode="MO" value="Macao" data-contry_code="853">Macao (+853)</option>
                        <option data-countrycode="MK" value="Macedonia, The Former Yugoslav Republic of" data-contry_code="389">Macedonia, The Former Yugoslav Republic of (+389)</option>
                        <option data-countrycode="MG" value="Madagascar" data-contry_code="261">Madagascar (+261)</option>
                        <option data-countrycode="MW" value="Malawi" data-contry_code="265">Malawi (+265)</option>
                        <option data-countrycode="MY" value="Malaysia" data-contry_code="60">Malaysia (+60)</option>
                        <option data-countrycode="MV" value="Maldives" data-contry_code="960">Maldives (+960)</option>
                        <option data-countrycode="ML" value="Mali" data-contry_code="223">Mali (+223)</option>
                        <option data-countrycode="MT" value="Malta" data-contry_code="356">Malta (+356)</option>
                        <option data-countrycode="MH" value="Marshall Islands" data-contry_code="692">Marshall Islands (+692)</option>
                        <option data-countrycode="MQ" value="Martinique" data-contry_code="596">Martinique (+596)</option>
                        <option data-countrycode="MR" value="Mauritania" data-contry_code="222">Mauritania (+222)</option>
                        <option data-countrycode="MU" value="Mauritius" data-contry_code="230">Mauritius (+230)</option>
                        <option data-countrycode="YT" value="Mayotte" data-contry_code="262">Mayotte (+262)</option>
                        <option data-countrycode="MX" value="Mexico" data-contry_code="52">Mexico (+52)</option>
                        <option data-countrycode="FM" value="Micronesia, Federated States of" data-contry_code="691">Micronesia, Federated States of (+691)</option>
                        <option data-countrycode="MD" value="Moldova" data-contry_code="373">Moldova (+373)</option>
                        <option data-countrycode="MC" value="Monaco" data-contry_code="377">Monaco (+377)</option>
                        <option data-countrycode="MN" value="Mongolia" data-contry_code="976">Mongolia (+976)</option>
                        <option data-countrycode="MS" value="Montserrat" data-contry_code="1-664">Montserrat (+1-664)</option>
                        <option data-countrycode="MA" value="Morocco" data-contry_code="212">Morocco (+212)</option>
                        <option data-countrycode="MZ" value="Mozambique" data-contry_code="258">Mozambique (+258)</option>
                        <option data-countrycode="MM" value="Myanmar" data-contry_code="95">Myanmar (+95)</option>
                        <option data-countrycode="NA" value="Namibia" data-contry_code="264">Namibia (+264)</option>
                        <option data-countrycode="NR" value="Nauru" data-contry_code="674">Nauru (+674)</option>
                        <option data-countrycode="NP" value="Nepal" data-contry_code="977">Nepal (+977)</option>
                        <option data-countrycode="NL" value="Netherlands" data-contry_code="31">Netherlands (+31)</option>
                        <option data-countrycode="AN" value="Netherlands Antilles" data-contry_code="599">Netherlands Antilles (+599)</option>
                        <option data-countrycode="NC" value="New Caledonia" data-contry_code="687">New Caledonia (+687 )</option>
                        <option data-countrycode="NZ" value="New Zealand" data-contry_code="64">New Zealand (+64)</option>
                        <option data-countrycode="NI" value="Nicaragua" data-contry_code="505">Nicaragua (+505)</option>
                        <option data-countrycode="NE" value="Niger" data-contry_code="227">Niger (+227)</option>
                        <option data-countrycode="NG" value="Nigeria" data-contry_code="234">Nigeria (+234)</option>
                        <option data-countrycode="NU" value="Niue" data-contry_code="683">Niue (+683)</option>
                        <option data-countrycode="NF" value="Norfolk Island" data-contry_code="672">Norfolk Island (+672)</option>
                        <option data-countrycode="MP" value="Northern Mariana Islands" data-contry_code="1-670">Northern Mariana Islands (+1-670)</option>
                        <option data-countrycode="NO" value="Norway" data-contry_code="47">Norway (+47)</option>
                        <option data-countrycode="OM" value="Oman" data-contry_code="968">Oman (+968)</option>
                        <option data-countrycode="PK" value="Pakistan" data-contry_code="92">Pakistan (+92)</option>
                        <option data-countrycode="PW" value="Palau" data-contry_code="680">Palau (+680)</option>
                        <option data-countrycode="PA" value="Panama" data-contry_code="507">Panama (+507)</option>
                        <option data-countrycode="PG" value="Papua New Guinea" data-contry_code="675">Papua New Guinea (+675)</option>
                        <option data-countrycode="PY" value="Paraguay" data-contry_code="595">Paraguay (+595)</option>
                        <option data-countrycode="PE" value="Peru" data-contry_code="51">Peru (+51)</option>
                        <option data-countrycode="PH" value="Philippines" data-contry_code="63">Philippines (+63)</option>
                        <option data-countrycode="PN" value="Pitcairn" data-contry_code="64">Pitcairn (+64)</option>
                        <option data-countrycode="PL" value="Poland" data-contry_code="48">Poland (+48)</option>
                        <option data-countrycode="PT" value="Portugal" data-contry_code="351">Portugal (+351)</option>
                        <option data-countrycode="PR" value="Puerto Rico" data-contry_code="1-787">Puerto Rico (+1-787)</option>
                        <option data-countrycode="QA" value="Qatar" data-contry_code="974">Qatar (+974)</option>
                        <option data-countrycode="RE" value="Reunion" data-contry_code="262">Reunion (+262)</option>
                        <option data-countrycode="RO" value="Romania" data-contry_code="40">Romania (+40)</option>
                        <option data-countrycode="RU" value="Russian Federation" data-contry_code="7">Russian Federation (+7)</option>
                        <option data-countrycode="RW" value="Rwanda" data-contry_code="250">Rwanda (+250)</option>
                        <option data-countrycode="KN" value="Saint Kitts and Nevis" data-contry_code="1-869">Saint Kitts and Nevis (+1-869)</option>
                        <option data-countrycode="LC" value="Saint Lucia" data-contry_code="1-758">Saint Lucia (+1-758)</option>
                        <option data-countrycode="VC" value="Saint Vincent and the Grenadines" data-contry_code="1-784">Saint Vincent and the Grenadines (+1-784)</option>
                        <option data-countrycode="WS" value="Samoa" data-contry_code="685">Samoa (+685)</option>
                        <option data-countrycode="SM" value="San Marino" data-contry_code="378">San Marino (+378)</option>
                        <option data-countrycode="ST" value="Sao Tome and Principe" data-contry_code="239">Sao Tome and Principe (+239)</option>
                        <option data-countrycode="SA" value="Saudi Arabia" data-contry_code="966">Saudi Arabia (+966)</option>
                        <option data-countrycode="SN" value="Senegal" data-contry_code="221">Senegal (+221)</option>
                        <option data-countrycode="SC" value="Seychelles" data-contry_code="248">Seychelles (+248)</option>
                        <option data-countrycode="SL" value="Sierra Leone" data-contry_code="232">Sierra Leone (+232)</option>
                        <option data-countrycode="SG" value="Singapore" data-contry_code="65">Singapore (+65)</option>
                        <option data-countrycode="SK" value="Slovakia (Slovak Republic)" data-contry_code="421">Slovakia (Slovak Republic) (+421)</option>
                        <option data-countrycode="SI" value="Slovenia" data-contry_code="386">Slovenia (+386)</option>
                        <option data-countrycode="SB" value="Solomon Islands" data-contry_code="677">Solomon Islands (+677)</option>
                        <option data-countrycode="SO" value="Somalia" data-contry_code="252">Somalia (+252)</option>
                        <option data-countrycode="ZA" value="South Africa" data-contry_code="27">South Africa (+27)</option>
                        <option data-countrycode="GS" value="South Georgia and the South Sandwich Islands" data-contry_code="500">South Georgia and the South Sandwich Islands (+500)</option>
                        <option data-countrycode="ES" value="Spain" data-contry_code="34">Spain (+34)</option>
                        <option data-countrycode="LK" value="Sri Lanka" data-contry_code="94">Sri Lanka (+94)</option>
                        <option data-countrycode="SH" value="Saint Helena, Ascension and Tristan da Cunha" data-contry_code="290">Saint Helena, Ascension and Tristan da Cunha (+290)</option>
                        <option data-countrycode="PM" value="St. Pierre and Miquelon" data-contry_code="508">St. Pierre and Miquelon (+508)</option>
                        <option data-countrycode="SD" value="Sudan" data-contry_code="249">Sudan (+249)</option>
                        <option data-countrycode="SR" value="Suriname" data-contry_code="597">Suriname (+597)</option>
                        <option data-countrycode="SJ" value="Svalbard and Jan Mayen Islands" data-contry_code="47">Svalbard and Jan Mayen Islands (+47)</option>
                        <option data-countrycode="SZ" value="Swaziland" data-contry_code="268">Swaziland (+268)</option>
                        <option data-countrycode="SE" value="Sweden" data-contry_code="46">Sweden (+46)</option>
                        <option data-countrycode="CH" value="Switzerland" data-contry_code="41">Switzerland (+41)</option>
                        <option data-countrycode="SY" value="Syrian Arab Republic" data-contry_code="963">Syrian Arab Republic (+963)</option>
                        <option data-countrycode="TW" value="Taiwan" data-contry_code="886">Taiwan (+886)</option>
                        <option data-countrycode="TJ" value="Tajikistan" data-contry_code="992">Tajikistan (+992)</option>
                        <option data-countrycode="TZ" value="Tanzania, United Republic of" data-contry_code="255">Tanzania, United Republic of (+255)</option>
                        <option data-countrycode="TH" value="Thailand" data-contry_code="66">Thailand (+66)</option>
                        <option data-countrycode="TG" value="Togo" data-contry_code="228">Togo (+228)</option>
                        <option data-countrycode="TK" value="Tokelau" data-contry_code="690">Tokelau (+690)</option>
                        <option data-countrycode="TO" value="Tonga" data-contry_code="676">Tonga (+676)</option>
                        <option data-countrycode="TT" value="Trinidad and Tobago" data-contry_code="1-868">Trinidad and Tobago (+1-868)</option>
                        <option data-countrycode="TN" value="Tunisia" data-contry_code="216">Tunisia (+216)</option>
                        <option data-countrycode="TR" value="Turkey" data-contry_code="90">Turkey (+90)</option>
                        <option data-countrycode="TM" value="Turkmenistan" data-contry_code="993">Turkmenistan (+993)</option>
                        <option data-countrycode="TC" value="Turks and Caicos Islands" data-contry_code="1-649">Turks and Caicos Islands (+1-649)</option>
                        <option data-countrycode="TV" value="Tuvalu" data-contry_code="688">Tuvalu (+688)</option>
                        <option data-countrycode="UG" value="Uganda" data-contry_code="256">Uganda (+256)</option>
                        <option data-countrycode="UA" value="Ukraine" data-contry_code="380">Ukraine (+380)</option>
                        <option data-countrycode="AE" value="United Arab Emirates" data-contry_code="971">United Arab Emirates (+971)</option>
                        <option data-countrycode="GB" value="United Kingdom" data-contry_code="44">United Kingdom (+44)</option>
                        <option data-countrycode="US" value="United States" data-contry_code="1">United States (+1)</option>
                        <option data-countrycode="UM" value="United States Minor Outlying Islands" data-contry_code="246">United States Minor Outlying Islands (+246)</option>
                        <option data-countrycode="UY" value="Uruguay" data-contry_code="598">Uruguay (+598)</option>
                        <option data-countrycode="UZ" value="Uzbekistan" data-contry_code="998">Uzbekistan (+998)</option>
                        <option data-countrycode="VU" value="Vanuatu" data-contry_code="678">Vanuatu (+678)</option>
                        <option data-countrycode="VA" value="Vatican City State (Holy See)" data-contry_code="379">Vatican City State (Holy See) (+379)</option>
                        <option data-countrycode="VE" value="Venezuela" data-contry_code="58">Venezuela (+58)</option>
                        <option data-countrycode="VN" value="Vietnam" data-contry_code="84">Vietnam (+84)</option>
                        <option data-countrycode="VG" value="Virgin Islands (British)" data-contry_code="1-284">Virgin Islands (British) (+1-284)</option>
                        <option data-countrycode="VI" value="Virgin Islands (U.S.)" data-contry_code="1-340">Virgin Islands (U.S.) (+1-340)</option>
                        <option data-countrycode="WF" value="Wallis and Futuna Islands" data-contry_code="681">Wallis and Futuna Islands (+681)</option>
                        <option data-countrycode="EH" value="Western Sahara" data-contry_code="212">Western Sahara (+212)</option>
                        <option data-countrycode="YE" value="Yemen" data-contry_code="967">Yemen (+967)</option>
                        <option data-countrycode="RS" value="Serbia" data-contry_code="381">Serbia (+381)</option>
                        <option data-countrycode="ZM" value="Zambia" data-contry_code="260">Zambia (+260)</option>
                        <option data-countrycode="ZW" value="Zimbabwe" data-contry_code="263">Zimbabwe (+263)</option>
                        <option data-countrycode="AX" value="Aaland Islands" data-contry_code="358">Aaland Islands (+358)</option>
                        <option data-countrycode="PS" value="Palestine" data-contry_code="970">Palestine (+970)</option>
                        <option data-countrycode="ME" value="Montenegro" data-contry_code="382">Montenegro (+382)</option>
                        <option data-countrycode="GG" value="Guernsey" data-contry_code="44-1481">Guernsey (+44-1481)</option>
                        <option data-countrycode="IM" value="Isle of Man" data-contry_code="44-1624">Isle of Man (+44-1624)</option>
                        <option data-countrycode="JE" value="Jersey" data-contry_code="44-1534">Jersey (+44-1534)</option>
                        <option data-countrycode="CW" value="CuraÃ§ao" data-contry_code="599">CuraÃ§ao (+599)</option>
                        <option data-countrycode="CI" value="Ivory Coast" data-contry_code="225">Ivory Coast (+225)</option>
                        <option data-countrycode="XK" value="Kosovo" data-contry_code="383">Kosovo (+383)</option> 
                    </select>
                    <input type="hidden" value="+91"  name="country_code" id="country_code" class="operations-supplierCapacity" />
                   
                    <input name="modal_my_mobile2" class="form-control numeric rounded-0 micro-form-field" id="modal_my_mobile" pattern="^[_0-9]+" placeholder="Phone number" type="text" value="" required="required" data-error="Please enter your valid mobile number" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')">
        			<input type="hidden" id="first_name" name="first_name">
        		    <input type="hidden" id="last_name" name="last_name">
                    <input type="hidden" id="builder" name="builder" value=" Birla Estates">
                    <input type="hidden" id="project" name="project" value="Birla Sector 71 Gurgaon ">
                    <input type=hidden id="lead_source" name="lead_source" value="Microsite">
                    <input type="hidden" name=ip id="ip" value="211.132.176.145">
                    <input type="hidden" name=mobile id="modal_dg_mobile2" class="mobileconcat">
                    <input type="hidden" id="enquiredfor" name="enquiredfor" value="Pre Register here for Best Offers">
                    <input type="hidden" name="home_url" value="https://www.birlassector71.com/birla-estate-sector71-gurugram/privacy-policy.php">
                    <input type="hidden" name="gclid" id="gclid" value="">
                    <input type="hidden" name="utm_source" id="utm_source" value="">
            <input type="hidden" name="utm_medium" id="utm_medium" value="">
            <input type="hidden" name="utm_campaign" id="utm_campaign" value="">
            <input type="hidden" name="utm_term" id="utm_term" value="">
            <input type="hidden" name="utm_physical_location" id="utm_physical_location" value="">
                <input type="hidden" name="utm_tragetid" id="utm_tragetid" value="">
                <input type="hidden" name="utm_target" id="utm_target" value="">
                <input type="hidden" name="utm_placement" id="utm_placement" value="">
                <input type="hidden" name="utm_adposition" id="utm_adposition" value="">
                <input type="hidden" id="organization_name" name="organization_name">
                    <input type="submit" value="Get It Now"  class="btn btn-info micro-form-btn effetMoveGradient submitBtn"  id="submitBtn">
                    <div><span class="errorMessage" id="errorMessage2" style="color: red; margin-left: 10px;"></span></div>
                </form>
                
            </div>
                       <div class="modal fade" id="enqModal"  role="dialog" aria-label="Connect with Us" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered enq-modal" role="document">
                    <div class="modal-content popmodal">
                        <div class="modal-body text-center">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <!--<div class="modal-head d-none"><span class="modal-title"> Download Brochure</span></div>-->
                            <div class="d-flex">
                                <div class="flex-fill align-self-center flex-shrink-1 modal-highlight-bg d-none d-lg-block popbox-left">
                                    <div class="poplogo-box"><span class="popup-logo"><img alt="Birla Sector 71 Gurgaon Logo" src="./assets/img/logo.svg" class="poplogo"></span></div>
                                    <div class="popleftsec">
                                        <div class="popleftinner">
                                            <span class="modal-highlight-title">We Promise</span>
                                            <ul class="modal-highlight">
                                                <li><i class="mi mi-support-call"></i><span>Instant Call Back</span></li>
                                                <li><i class="mi mi-support-visit"></i><span>Free Site Visit</span></li>
                                                <li><i class="mi mi-support-price"></i><span>Unmatched Price</span></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex-fill popbox-right">
                                    <div class="modal-head d-none"><span class="modal-title"> Download Brochure</span></div>
                                     <div class="poplogo-box desktop"><span class="popup-logo"><img alt="Birla Sector 71 Gurgaon Logo" src="./assets/img/logo.svg" class="poplogo logo"></span></div>
                                    <span class="modal-title-secondary text-left"> Register here and Avail the <span class="text-danger">Best Offers!!</span></span>
                                    <form action="https://microsite.fanmrealty.com/live/lead-callback-v25.php" method="post" class="form-side" id="pardotForm" class="pardotForm">
                                    <input type="text" id="fname" placeholder="Name" name="fname" class="form-control rounded-0 micro-form-field" required>
                                    <div class="error" id="name_error"></div>
                                    <input type="email" id="email" placeholder="Email Address(Optional)" name="email" class="form-control rounded-0 micro-form-field">
                                    <div class="error" id="address_error"></div>
                                    <select class="my_country_name form-control rounded-0 micro-form-field" aria-label="countryname" name="country_name">
                               <option data-countrycode="IN" value="India" data-contry_code="91">India (+91)</option>
                                        <option data-countrycode="AF" value="Afghanistan" data-contry_code="93">Afghanistan (+93)</option>
                                        <option data-countrycode="AL" value="Albania" data-contry_code="355">Albania (+355)</option>
                                        <option data-countrycode="DZ" value="Algeria" data-contry_code="213">Algeria (+213)</option>
                                        <option data-countrycode="AS" value="American Samoa" data-contry_code="1-684">American Samoa (+1-684)</option>
                                        <option data-countrycode="AD" value="Andorra" data-contry_code="376">Andorra (+376)</option>
                                        <option data-countrycode="AO" value="Angola" data-contry_code="244">Angola (+244)</option>
                                        <option data-countrycode="AI" value="Anguilla" data-contry_code="1-264">Anguilla (+1-264)</option>
                                        <option data-countrycode="AQ" value="Antarctica" data-contry_code="672">Antarctica (+672)</option>
                                        <option data-countrycode="AG" value="Antigua and Barbuda" data-contry_code="1-268">Antigua and Barbuda (+1-268)</option>
                                        <option data-countrycode="AR" value="Argentina" data-contry_code="54">Argentina (+54)</option>
                                        <option data-countrycode="AM" value="Armenia" data-contry_code="374">Armenia (+374)</option>
                                        <option data-countrycode="AW" value="Aruba" data-contry_code="297">Aruba (+297)</option>
                                        <option data-countrycode="AU" value="Australia" data-contry_code="61">Australia (+61)</option>
                                        <option data-countrycode="AT" value="Austria" data-contry_code="43">Austria (+43)</option>
                                        <option data-countrycode="AZ" value="Azerbaijan" data-contry_code="994">Azerbaijan (+994)</option>
                                        <option data-countrycode="BS" value="Bahamas" data-contry_code="1-242">Bahamas (+1-242)</option>
                                        <option data-countrycode="BH" value="Bahrain" data-contry_code="973">Bahrain (+973)</option>
                                        <option data-countrycode="BD" value="Bangladesh" data-contry_code="880">Bangladesh (+880)</option>
                                        <option data-countrycode="BB" value="Barbados" data-contry_code="1-246">Barbados (+1-246)</option>
                                        <option data-countrycode="BY" value="Belarus" data-contry_code="375">Belarus (+375)</option>
                                        <option data-countrycode="BE" value="Belgium" data-contry_code="32">Belgium (+32)</option>
                                        <option data-countrycode="BZ" value="Belize" data-contry_code="501">Belize (+501)</option>
                                        <option data-countrycode="BJ" value="Benin" data-contry_code="229">Benin (+229)</option>
                                        <option data-countrycode="BM" value="Bermuda" data-contry_code="1-441">Bermuda (+1-441)</option>
                                        <option data-countrycode="BT" value="Bhutan" data-contry_code="975">Bhutan (+975)</option>
                                        <option data-countrycode="BO" value="Bolivia" data-contry_code="591">Bolivia (+591)</option>
                                        <option data-countrycode="BA" value="Bosnia and Herzegowina" data-contry_code="387">Bosnia and Herzegowina (+387)</option>
                                        <option data-countrycode="BW" value="Botswana" data-contry_code="267">Botswana (+267)</option>
                                        <option data-countrycode="BV" value="Bouvet Island" data-contry_code="47">Bouvet Island (+47)</option>
                                        <option data-countrycode="BR" value="Brazil" data-contry_code="55">Brazil (+55)</option>
                                        <option data-countrycode="IO" value="British Indian Ocean Territory" data-contry_code="246">British Indian Ocean Territory (+246)</option>
                                        <option data-countrycode="BN" value="Brunei Darussalam" data-contry_code="673">Brunei Darussalam (+673)</option>
                                        <option data-countrycode="BG" value="Bulgaria" data-contry_code="359">Bulgaria (+359)</option>
                                        <option data-countrycode="BF" value="Burkina Faso" data-contry_code="226">Burkina Faso (+226)</option>
                                        <option data-countrycode="BI" value="Burundi" data-contry_code="257">Burundi (+257)</option>
                                        <option data-countrycode="KH" value="Cambodia" data-contry_code="855">Cambodia (+855)</option>
                                        <option data-countrycode="CM" value="Cameroon" data-contry_code="237">Cameroon (+237)</option>
                                        <option data-countrycode="CA" value="Canada" data-contry_code="1">Canada (+1)</option>
                                        <option data-countrycode="CV" value="Cape Verde" data-contry_code="238">Cape Verde (+238)</option>
                                        <option data-countrycode="KY" value="Cayman Islands" data-contry_code="1-345">Cayman Islands (+1-345)</option>
                                        <option data-countrycode="CF" value="Central African Republic" data-contry_code="236">Central African Republic (+236)</option>
                                        <option data-countrycode="TD" value="Chad" data-contry_code="235">Chad (+235)</option>
                                        <option data-countrycode="CL" value="Chile" data-contry_code="56">Chile (+56)</option>
                                        <option data-countrycode="CN" value="China" data-contry_code="86">China (+86)</option>
                                        <option data-countrycode="CX" value="Christmas Island" data-contry_code="61">Christmas Island (+61)</option>
                                        <option data-countrycode="CC" value="Cocos (Keeling) Islands" data-contry_code="61">Cocos (Keeling) Islands (+61)</option>
                                        <option data-countrycode="CO" value="Colombia" data-contry_code="57">Colombia (+57)</option>
                                        <option data-countrycode="KM" value="Comoros" data-contry_code="269">Comoros (+269)</option>
                                        <option data-countrycode="CG" value="Congo Democratic Republic of" data-contry_code="242">Congo Democratic Republic of (+242)</option>
                                        <option data-countrycode="CK" value="Cook Islands" data-contry_code="682">Cook Islands (+682)</option>
                                        <option data-countrycode="CR" value="Costa Rica" data-contry_code="506">Costa Rica (+506)</option>
                                        <option data-countrycode="CI" value="Cote D'Ivoire" data-contry_code="225">Cote D'Ivoire (+225)</option>
                                        <option data-countrycode="HR" value="Croatia" data-contry_code="385">Croatia (+385)</option>
                                        <option data-countrycode="CU" value="Cuba" data-contry_code="53">Cuba (+53)</option>
                                        <option data-countrycode="CY" value="Cyprus" data-contry_code="357">Cyprus (+357)</option>
                                        <option data-countrycode="CZ" value="Czech Republic" data-contry_code="420">Czech Republic (+420)</option>
                                        <option data-countrycode="DK" value="Denmark" data-contry_code="45">Denmark (+45)</option>
                                        <option data-countrycode="DJ" value="Djibouti" data-contry_code="253">Djibouti (+253)</option>
                                        <option data-countrycode="DM" value="Dominica" data-contry_code="1-767">Dominica (+1-767)</option>
                                        <option data-countrycode="DO" value="Dominican Republic" data-contry_code="1-809">Dominican Republic (+1-809)</option>
                                        <option data-countrycode="TL" value="Timor-Leste" data-contry_code="670">Timor-Leste (+670)</option>
                                        <option data-countrycode="EC" value="Ecuador" data-contry_code="593">Ecuador (+593)</option>
                                        <option data-countrycode="EG" value="Egypt" data-contry_code="20">Egypt (+20)</option>
                                        <option data-countrycode="SV" value="El Salvador" data-contry_code="503">El Salvador (+503)</option>
                                        <option data-countrycode="GQ" value="Equatorial Guinea" data-contry_code="240">Equatorial Guinea (+240)</option>
                                        <option data-countrycode="ER" value="Eritrea" data-contry_code="291">Eritrea (+291)</option>
                                        <option data-countrycode="EE" value="Estonia" data-contry_code="372">Estonia (+372)</option>
                                        <option data-countrycode="ET" value="Ethiopia" data-contry_code="251">Ethiopia (+251)</option>
                                        <option data-countrycode="FK" value="Falkland Islands (Malvinas)" data-contry_code="500">Falkland Islands (Malvinas) (+500)</option>
                                        <option data-countrycode="FO" value="Faroe Islands" data-contry_code="298">Faroe Islands (+298)</option>
                                        <option data-countrycode="FJ" value="Fiji" data-contry_code="679">Fiji (+679)</option>
                                        <option data-countrycode="FI" value="Finland" data-contry_code="358">Finland (+358)</option>
                                        <option data-countrycode="FR" value="France" data-contry_code="33">France (+33)</option>
                                        <option data-countrycode="GF" value="French Guiana" data-contry_code="594">French Guiana (+594)</option>
                                        <option data-countrycode="PF" value="French Polynesia" data-contry_code="689">French Polynesia (+689)</option>
                                        <option data-countrycode="GA" value="Gabon" data-contry_code="241">Gabon (+241)</option>
                                        <option data-countrycode="GM" value="Gambia" data-contry_code="220">Gambia (+220)</option>
                                        <option data-countrycode="GE" value="Georgia" data-contry_code="995">Georgia (+995)</option>
                                        <option data-countrycode="DE" value="Germany" data-contry_code="49">Germany (+49)</option>
                                        <option data-countrycode="GH" value="Ghana" data-contry_code="233">Ghana (+233)</option>
                                        <option data-countrycode="GI" value="Gibraltar" data-contry_code="350">Gibraltar (+350)</option>
                                        <option data-countrycode="GR" value="Greece" data-contry_code="30">Greece (+30)</option>
                                        <option data-countrycode="GL" value="Greenland" data-contry_code="299">Greenland (+299)</option>
                                        <option data-countrycode="GD" value="Grenada" data-contry_code="1-473">Grenada (+1-473)</option>
                                        <option data-countrycode="GP" value="Guadeloupe" data-contry_code="590">Guadeloupe (+590)</option>
                                        <option data-countrycode="GU" value="Guam" data-contry_code="1-671">Guam (+1-671)</option>
                                        <option data-countrycode="GT" value="Guatemala" data-contry_code="502">Guatemala (+502)</option>
                                        <option data-countrycode="GN" value="Guinea" data-contry_code="224">Guinea (+224)</option>
                                        <option data-countrycode="GW" value="Guinea-bissau" data-contry_code="245">Guinea-bissau (+245)</option>
                                        <option data-countrycode="GY" value="Guyana" data-contry_code="592">Guyana (+592)</option>
                                        <option data-countrycode="HT" value="Haiti" data-contry_code="509">Haiti (+509)</option>
                                        <option data-countrycode="HM" value="Heard Island and McDonald Islands" data-contry_code="011">Heard Island and McDonald Islands (+011)</option>
                                        <option data-countrycode="HN" value="Honduras" data-contry_code="504">Honduras (+504)</option>
                                        <option data-countrycode="HK" value="Hong Kong" data-contry_code="852">Hong Kong (+852)</option>
                                        <option data-countrycode="HU" value="Hungary" data-contry_code="36">Hungary (+36)</option>
                                        <option data-countrycode="IS" value="Iceland" data-contry_code="354">Iceland (+354)</option>
                                        <option data-countrycode="IN" value="India" data-contry_code="91" selected="">India (+91)</option>
                                        <option data-countrycode="ID" value="Indonesia" data-contry_code="62">Indonesia (+62)</option>
                                        <option data-countrycode="IR" value="Iran (Islamic Republic of)" data-contry_code="98">Iran (Islamic Republic of) (+98)</option>
                                        <option data-countrycode="IQ" value="Iraq" data-contry_code="964">Iraq (+964)</option>
                                        <option data-countrycode="IE" value="Ireland" data-contry_code="353">Ireland (+353)</option>
                                        <option data-countrycode="IL" value="Israel" data-contry_code="972">Israel (+972)</option>
                                        <option data-countrycode="IT" value="Italy" data-contry_code="39">Italy (+39)</option>
                                        <option data-countrycode="JM" value="Jamaica" data-contry_code="1-876">Jamaica (+1-876)</option>
                                        <option data-countrycode="JP" value="Japan" data-contry_code="81">Japan (+81)</option>
                                        <option data-countrycode="JO" value="Jordan" data-contry_code="962">Jordan (+962)</option>
                                        <option data-countrycode="KZ" value="Kazakhstan" data-contry_code="7">Kazakhstan (+7)</option>
                                        <option data-countrycode="KE" value="Kenya" data-contry_code="254">Kenya (+254)</option>
                                        <option data-countrycode="KI" value="Kiribati" data-contry_code="686">Kiribati (+686)</option>
                                        <option data-countrycode="KP" value="Korea, Democratic People's Republic of" data-contry_code="850">Korea, Democratic People's Republic of (+850)</option>
                                        <option data-countrycode="KR" value="South Korea" data-contry_code="82">South Korea (+82)</option>
                                        <option data-countrycode="KW" value="Kuwait" data-contry_code="965">Kuwait (+965)</option>
                                        <option data-countrycode="KG" value="Kyrgyzstan" data-contry_code="996">Kyrgyzstan (+996)</option>
                                        <option data-countrycode="LA" value="Lao People's Democratic Republic" data-contry_code="856">Lao People's Democratic Republic (+856)</option>
                                        <option data-countrycode="LV" value="Latvia" data-contry_code="371">Latvia (+371)</option>
                                        <option data-countrycode="LB" value="Lebanon" data-contry_code="961">Lebanon (+961)</option>
                                        <option data-countrycode="LS" value="Lesotho" data-contry_code="266">Lesotho (+266)</option>
                                        <option data-countrycode="LR" value="Liberia" data-contry_code="231">Liberia (+231)</option>
                                        <option data-countrycode="LY" value="Libya" data-contry_code="218">Libya (+218)</option>
                                        <option data-countrycode="LI" value="Liechtenstein" data-contry_code="423">Liechtenstein (+423)</option>
                                        <option data-countrycode="LT" value="Lithuania" data-contry_code="370">Lithuania (+370)</option>
                                        <option data-countrycode="LU" value="Luxembourg" data-contry_code="352">Luxembourg (+352)</option>
                                        <option data-countrycode="MO" value="Macao" data-contry_code="853">Macao (+853)</option>
                                        <option data-countrycode="MK" value="Macedonia, The Former Yugoslav Republic of" data-contry_code="389">Macedonia, The Former Yugoslav Republic of (+389)</option>
                                        <option data-countrycode="MG" value="Madagascar" data-contry_code="261">Madagascar (+261)</option>
                                        <option data-countrycode="MW" value="Malawi" data-contry_code="265">Malawi (+265)</option>
                                        <option data-countrycode="MY" value="Malaysia" data-contry_code="60">Malaysia (+60)</option>
                                        <option data-countrycode="MV" value="Maldives" data-contry_code="960">Maldives (+960)</option>
                                        <option data-countrycode="ML" value="Mali" data-contry_code="223">Mali (+223)</option>
                                        <option data-countrycode="MT" value="Malta" data-contry_code="356">Malta (+356)</option>
                                        <option data-countrycode="MH" value="Marshall Islands" data-contry_code="692">Marshall Islands (+692)</option>
                                        <option data-countrycode="MQ" value="Martinique" data-contry_code="596">Martinique (+596)</option>
                                        <option data-countrycode="MR" value="Mauritania" data-contry_code="222">Mauritania (+222)</option>
                                        <option data-countrycode="MU" value="Mauritius" data-contry_code="230">Mauritius (+230)</option>
                                        <option data-countrycode="YT" value="Mayotte" data-contry_code="262">Mayotte (+262)</option>
                                        <option data-countrycode="MX" value="Mexico" data-contry_code="52">Mexico (+52)</option>
                                        <option data-countrycode="FM" value="Micronesia, Federated States of" data-contry_code="691">Micronesia, Federated States of (+691)</option>
                                        <option data-countrycode="MD" value="Moldova" data-contry_code="373">Moldova (+373)</option>
                                        <option data-countrycode="MC" value="Monaco" data-contry_code="377">Monaco (+377)</option>
                                        <option data-countrycode="MN" value="Mongolia" data-contry_code="976">Mongolia (+976)</option>
                                        <option data-countrycode="MS" value="Montserrat" data-contry_code="1-664">Montserrat (+1-664)</option>
                                        <option data-countrycode="MA" value="Morocco" data-contry_code="212">Morocco (+212)</option>
                                        <option data-countrycode="MZ" value="Mozambique" data-contry_code="258">Mozambique (+258)</option>
                                        <option data-countrycode="MM" value="Myanmar" data-contry_code="95">Myanmar (+95)</option>
                                        <option data-countrycode="NA" value="Namibia" data-contry_code="264">Namibia (+264)</option>
                                        <option data-countrycode="NR" value="Nauru" data-contry_code="674">Nauru (+674)</option>
                                        <option data-countrycode="NP" value="Nepal" data-contry_code="977">Nepal (+977)</option>
                                        <option data-countrycode="NL" value="Netherlands" data-contry_code="31">Netherlands (+31)</option>
                                        <option data-countrycode="AN" value="Netherlands Antilles" data-contry_code="599">Netherlands Antilles (+599)</option>
                                        <option data-countrycode="NC" value="New Caledonia" data-contry_code="687">New Caledonia (+687 )</option>
                                        <option data-countrycode="NZ" value="New Zealand" data-contry_code="64">New Zealand (+64)</option>
                                        <option data-countrycode="NI" value="Nicaragua" data-contry_code="505">Nicaragua (+505)</option>
                                        <option data-countrycode="NE" value="Niger" data-contry_code="227">Niger (+227)</option>
                                        <option data-countrycode="NG" value="Nigeria" data-contry_code="234">Nigeria (+234)</option>
                                        <option data-countrycode="NU" value="Niue" data-contry_code="683">Niue (+683)</option>
                                        <option data-countrycode="NF" value="Norfolk Island" data-contry_code="672">Norfolk Island (+672)</option>
                                        <option data-countrycode="MP" value="Northern Mariana Islands" data-contry_code="1-670">Northern Mariana Islands (+1-670)</option>
                                        <option data-countrycode="NO" value="Norway" data-contry_code="47">Norway (+47)</option>
                                        <option data-countrycode="OM" value="Oman" data-contry_code="968">Oman (+968)</option>
                                        <option data-countrycode="PK" value="Pakistan" data-contry_code="92">Pakistan (+92)</option>
                                        <option data-countrycode="PW" value="Palau" data-contry_code="680">Palau (+680)</option>
                                        <option data-countrycode="PA" value="Panama" data-contry_code="507">Panama (+507)</option>
                                        <option data-countrycode="PG" value="Papua New Guinea" data-contry_code="675">Papua New Guinea (+675)</option>
                                        <option data-countrycode="PY" value="Paraguay" data-contry_code="595">Paraguay (+595)</option>
                                        <option data-countrycode="PE" value="Peru" data-contry_code="51">Peru (+51)</option>
                                        <option data-countrycode="PH" value="Philippines" data-contry_code="63">Philippines (+63)</option>
                                        <option data-countrycode="PN" value="Pitcairn" data-contry_code="64">Pitcairn (+64)</option>
                                        <option data-countrycode="PL" value="Poland" data-contry_code="48">Poland (+48)</option>
                                        <option data-countrycode="PT" value="Portugal" data-contry_code="351">Portugal (+351)</option>
                                        <option data-countrycode="PR" value="Puerto Rico" data-contry_code="1-787">Puerto Rico (+1-787)</option>
                                        <option data-countrycode="QA" value="Qatar" data-contry_code="974">Qatar (+974)</option>
                                        <option data-countrycode="RE" value="Reunion" data-contry_code="262">Reunion (+262)</option>
                                        <option data-countrycode="RO" value="Romania" data-contry_code="40">Romania (+40)</option>
                                        <option data-countrycode="RU" value="Russian Federation" data-contry_code="7">Russian Federation (+7)</option>
                                        <option data-countrycode="RW" value="Rwanda" data-contry_code="250">Rwanda (+250)</option>
                                        <option data-countrycode="KN" value="Saint Kitts and Nevis" data-contry_code="1-869">Saint Kitts and Nevis (+1-869)</option>
                                        <option data-countrycode="LC" value="Saint Lucia" data-contry_code="1-758">Saint Lucia (+1-758)</option>
                                        <option data-countrycode="VC" value="Saint Vincent and the Grenadines" data-contry_code="1-784">Saint Vincent and the Grenadines (+1-784)</option>
                                        <option data-countrycode="WS" value="Samoa" data-contry_code="685">Samoa (+685)</option>
                                        <option data-countrycode="SM" value="San Marino" data-contry_code="378">San Marino (+378)</option>
                                        <option data-countrycode="ST" value="Sao Tome and Principe" data-contry_code="239">Sao Tome and Principe (+239)</option>
                                        <option data-countrycode="SA" value="Saudi Arabia" data-contry_code="966">Saudi Arabia (+966)</option>
                                        <option data-countrycode="SN" value="Senegal" data-contry_code="221">Senegal (+221)</option>
                                        <option data-countrycode="SC" value="Seychelles" data-contry_code="248">Seychelles (+248)</option>
                                        <option data-countrycode="SL" value="Sierra Leone" data-contry_code="232">Sierra Leone (+232)</option>
                                        <option data-countrycode="SG" value="Singapore" data-contry_code="65">Singapore (+65)</option>
                                        <option data-countrycode="SK" value="Slovakia (Slovak Republic)" data-contry_code="421">Slovakia (Slovak Republic) (+421)</option>
                                        <option data-countrycode="SI" value="Slovenia" data-contry_code="386">Slovenia (+386)</option>
                                        <option data-countrycode="SB" value="Solomon Islands" data-contry_code="677">Solomon Islands (+677)</option>
                                        <option data-countrycode="SO" value="Somalia" data-contry_code="252">Somalia (+252)</option>
                                        <option data-countrycode="ZA" value="South Africa" data-contry_code="27">South Africa (+27)</option>
                                        <option data-countrycode="GS" value="South Georgia and the South Sandwich Islands" data-contry_code="500">South Georgia and the South Sandwich Islands (+500)</option>
                                        <option data-countrycode="ES" value="Spain" data-contry_code="34">Spain (+34)</option>
                                        <option data-countrycode="LK" value="Sri Lanka" data-contry_code="94">Sri Lanka (+94)</option>
                                        <option data-countrycode="SH" value="Saint Helena, Ascension and Tristan da Cunha" data-contry_code="290">Saint Helena, Ascension and Tristan da Cunha (+290)</option>
                                        <option data-countrycode="PM" value="St. Pierre and Miquelon" data-contry_code="508">St. Pierre and Miquelon (+508)</option>
                                        <option data-countrycode="SD" value="Sudan" data-contry_code="249">Sudan (+249)</option>
                                        <option data-countrycode="SR" value="Suriname" data-contry_code="597">Suriname (+597)</option>
                                        <option data-countrycode="SJ" value="Svalbard and Jan Mayen Islands" data-contry_code="47">Svalbard and Jan Mayen Islands (+47)</option>
                                        <option data-countrycode="SZ" value="Swaziland" data-contry_code="268">Swaziland (+268)</option>
                                        <option data-countrycode="SE" value="Sweden" data-contry_code="46">Sweden (+46)</option>
                                        <option data-countrycode="CH" value="Switzerland" data-contry_code="41">Switzerland (+41)</option>
                                        <option data-countrycode="SY" value="Syrian Arab Republic" data-contry_code="963">Syrian Arab Republic (+963)</option>
                                        <option data-countrycode="TW" value="Taiwan" data-contry_code="886">Taiwan (+886)</option>
                                        <option data-countrycode="TJ" value="Tajikistan" data-contry_code="992">Tajikistan (+992)</option>
                                        <option data-countrycode="TZ" value="Tanzania, United Republic of" data-contry_code="255">Tanzania, United Republic of (+255)</option>
                                        <option data-countrycode="TH" value="Thailand" data-contry_code="66">Thailand (+66)</option>
                                        <option data-countrycode="TG" value="Togo" data-contry_code="228">Togo (+228)</option>
                                        <option data-countrycode="TK" value="Tokelau" data-contry_code="690">Tokelau (+690)</option>
                                        <option data-countrycode="TO" value="Tonga" data-contry_code="676">Tonga (+676)</option>
                                        <option data-countrycode="TT" value="Trinidad and Tobago" data-contry_code="1-868">Trinidad and Tobago (+1-868)</option>
                                        <option data-countrycode="TN" value="Tunisia" data-contry_code="216">Tunisia (+216)</option>
                                        <option data-countrycode="TR" value="Turkey" data-contry_code="90">Turkey (+90)</option>
                                        <option data-countrycode="TM" value="Turkmenistan" data-contry_code="993">Turkmenistan (+993)</option>
                                        <option data-countrycode="TC" value="Turks and Caicos Islands" data-contry_code="1-649">Turks and Caicos Islands (+1-649)</option>
                                        <option data-countrycode="TV" value="Tuvalu" data-contry_code="688">Tuvalu (+688)</option>
                                        <option data-countrycode="UG" value="Uganda" data-contry_code="256">Uganda (+256)</option>
                                        <option data-countrycode="UA" value="Ukraine" data-contry_code="380">Ukraine (+380)</option>
                                        <option data-countrycode="AE" value="United Arab Emirates" data-contry_code="971">United Arab Emirates (+971)</option>
                                        <option data-countrycode="GB" value="United Kingdom" data-contry_code="44">United Kingdom (+44)</option>
                                        <option data-countrycode="US" value="United States" data-contry_code="1">United States (+1)</option>
                                        <option data-countrycode="UM" value="United States Minor Outlying Islands" data-contry_code="246">United States Minor Outlying Islands (+246)</option>
                                        <option data-countrycode="UY" value="Uruguay" data-contry_code="598">Uruguay (+598)</option>
                                        <option data-countrycode="UZ" value="Uzbekistan" data-contry_code="998">Uzbekistan (+998)</option>
                                        <option data-countrycode="VU" value="Vanuatu" data-contry_code="678">Vanuatu (+678)</option>
                                        <option data-countrycode="VA" value="Vatican City State (Holy See)" data-contry_code="379">Vatican City State (Holy See) (+379)</option>
                                        <option data-countrycode="VE" value="Venezuela" data-contry_code="58">Venezuela (+58)</option>
                                        <option data-countrycode="VN" value="Vietnam" data-contry_code="84">Vietnam (+84)</option>
                                        <option data-countrycode="VG" value="Virgin Islands (British)" data-contry_code="1-284">Virgin Islands (British) (+1-284)</option>
                                        <option data-countrycode="VI" value="Virgin Islands (U.S.)" data-contry_code="1-340">Virgin Islands (U.S.) (+1-340)</option>
                                        <option data-countrycode="WF" value="Wallis and Futuna Islands" data-contry_code="681">Wallis and Futuna Islands (+681)</option>
                                        <option data-countrycode="EH" value="Western Sahara" data-contry_code="212">Western Sahara (+212)</option>
                                        <option data-countrycode="YE" value="Yemen" data-contry_code="967">Yemen (+967)</option>
                                        <option data-countrycode="RS" value="Serbia" data-contry_code="381">Serbia (+381)</option>
                                        <option data-countrycode="ZM" value="Zambia" data-contry_code="260">Zambia (+260)</option>
                                        <option data-countrycode="ZW" value="Zimbabwe" data-contry_code="263">Zimbabwe (+263)</option>
                                        <option data-countrycode="AX" value="Aaland Islands" data-contry_code="358">Aaland Islands (+358)</option>
                                        <option data-countrycode="PS" value="Palestine" data-contry_code="970">Palestine (+970)</option>
                                        <option data-countrycode="ME" value="Montenegro" data-contry_code="382">Montenegro (+382)</option>
                                        <option data-countrycode="GG" value="Guernsey" data-contry_code="44-1481">Guernsey (+44-1481)</option>
                                        <option data-countrycode="IM" value="Isle of Man" data-contry_code="44-1624">Isle of Man (+44-1624)</option>
                                        <option data-countrycode="JE" value="Jersey" data-contry_code="44-1534">Jersey (+44-1534)</option>
                                        <option data-countrycode="CW" value="CuraÃ§ao" data-contry_code="599">CuraÃ§ao (+599)</option>
                                        <option data-countrycode="CI" value="Ivory Coast" data-contry_code="225">Ivory Coast (+225)</option>
                                        <option data-countrycode="XK" value="Kosovo" data-contry_code="383">Kosovo (+383)</option> 
                                    </select>
                                    <input type="hidden" value="91" name="country_code" id="country_code" class="operations-supplierCapacity" />
                                    <input name="modal_my_mobile2" class="form-control numeric rounded-0 micro-form-field" id="modal_my_mobile" pattern="^[_0-9]+" placeholder="Phone number" type="text" value="" required="required" data-error="Please enter your valid mobile number" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')">
                                    <!--<input type="hidden" name="my_country_name" id="country" value="India">-->
    		                    	<input type="hidden" id="first_name" name="first_name">
    		                        <input type="hidden" id="last_name" name="last_name">
                                    <input type="hidden" id="builder" name="builder" value=" Birla Estates">
                                    <input type="hidden" id="project" name="project" value="Birla Sector 71 Gurgaon ">
                                    <input type=hidden id="lead_source" name="lead_source" value="Microsite">
                                    <input type="hidden" name=ip id="ip" value="211.132.176.145">
                                    <input type="hidden" name=mobile id="modal_dg_mobile" class="mobileconcat">
                                    <input type="hidden" id="enquiredfor" name="enquiredfor" value="Get Instant Call Back Home Page Pop Up">
                                    <input type="hidden" name="home_url" value="https://www.birlassector71.com/birla-estate-sector71-gurugram/privacy-policy.php">
                                    <input type="hidden" name="gclid" id="gclid" value="">
                                    <input type="hidden" name="utm_source" id="utm_source" value="">
            <input type="hidden" name="utm_medium" id="utm_medium" value="">
            <input type="hidden" name="utm_campaign" id="utm_campaign" value="">
            <input type="hidden" name="utm_term" id="utm_term" value="">
            <input type="hidden" name="utm_physical_location" id="utm_physical_location" value="">
                <input type="hidden" name="utm_tragetid" id="utm_tragetid" value="">
                <input type="hidden" name="utm_target" id="utm_target" value="">
                <input type="hidden" name="utm_placement" id="utm_placement" value="">
                <input type="hidden" name="utm_adposition" id="utm_adposition" value="">
                <input type="hidden" id="organization_name" name="organization_name">
                <button type="submit" class="btn micro-form-btn submitBtn" id="submitBtn" style="margin-top:10px;margin-bottom:10px">Get Instant Call Back</button>
                 
                <div><span class="errorMessage" id="errorMessage2" style="color: red; margin-left: 10px;"></span></div>
                </form>
                
               </div>
                                  
               </div>
        <!--Privacy Policy LINK-->
        <!--<small class="modal-call-btn bg-white">-->
    <!--CONTACT NO-->
            <a href="tel:+912246181156" aria-label="Contact No." class="popcallbtn modal-call-btn d-block" style="padding: 0.5rem 1rem;"><i class="mi mi-call"></i> +912246181156</a>
            <!-- Slide to Call  -->
            
    <!--</small> -->
                        </div>
                    </div>
                </div>
            </div>
<!-- Slide to Call Script start -->
            
<!-- Slide to Call Script end -->
<!--DOWNLOAD BROCHURE BUTTON START-->
            <div class="download-brochure">
                <div class="desk_brochure">
                    <a
                        class="enqModal"
                        href="#"
                        data-form="md"
                        data-title="Download brochure"
                        data-btn="Download now"
                        data-enquiry="Download Brochure Sticky Desktop"
                        data-redirect="brochure"
                        data-redirect-file="brochure.pdf"
                        data-toggle="modal"
                        data-target="#enqModal">
                        <img src="./assets/img/brochure_icon_n1.gif" loading="lazy">
                    </a>
                </div>
                <div class="mob_brochure">
                    <a
                        class="enqModal"
                        href="#"
                        data-form="md"
                        data-title="Download brochure"
                        data-btn="Download now"
                        data-enquiry="Download Brochure Sticky Mobile"
                        data-redirect="brochure"
                        data-redirect-file="brochure.pdf"
                        data-toggle="modal"
                        data-target="#enqModal">
                        <img src="./assets/img/brochure_icon_mob_n1.gif" loading="lazy">
                    </a>
                </div>
            </div>
         <!--COOKIES CODE START-->
            <style>
                .cookiealert {position: fixed;bottom: 0;left: 0;width: 100%;margin: 0 !important;z-index: 9999;opacity: 0;visibility: hidden;border-radius: 0;transform: translateY(100%);transition: all 500ms ease-out;color: #ecf0f1;background: #212327;}
                .cookiealert.show {opacity: 1;visibility: visible;transform: translateY(0%);transition-delay: 1000ms;}
                .cookiealert a {text-decoration: underline}
                .cookiealert .acceptcookies {margin-left: 10px;vertical-align: baseline;}
            </style>
            <script>
                (function () {
                    "use strict";
               
                    var cookieAlert = document.querySelector(".cookiealert");
                    var acceptCookies = document.querySelector(".acceptcookies");
               
                    if (!cookieAlert) {
                       return;
                    }
               
                    cookieAlert.offsetHeight;
               
                    // Show the alert if we cant find the "acceptCookies" cookie
                    if (!getCookie("acceptCookies")) {
                        cookieAlert.classList.add("show");
                    }
               
                    // When clicking on the agree button, create a 1 year
                    // cookie to remember user's choice and close the banner
                    acceptCookies.addEventListener("click", function () {
                        setCookie("acceptCookies", true, 365);
                        cookieAlert.classList.remove("show");
               
                        // dispatch the accept event
                        window.dispatchEvent(new Event("cookieAlertAccept"))
                    });
               
                    // Cookie functions from w3schools
                    function setCookie(cname, cvalue, exdays) {
                        var d = new Date();
                        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                        var expires = "expires=" + d.toUTCString();
                        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
                    }
               
                    function getCookie(cname) {
                        var name = cname + "=";
                        var decodedCookie = decodeURIComponent(document.cookie);
                        var ca = decodedCookie.split(';');
                        for (var i = 0; i < ca.length; i++) {
                            var c = ca[i];
                            while (c.charAt(0) === ' ') {
                                c = c.substring(1);
                            }
                            if (c.indexOf(name) === 0) {
                                return c.substring(name.length, c.length);
                            }
                        }
                        return "";
                    }
                })();
            </script>
            <!--COOKIES CODE END-->
       <!-- Start of Async Drift Code --> 
        <script  defer="defer">
            var executed = true;
            var h1tag = "Birla Sector 71 ";
            window.onscroll = function () {
            var addressSection = document.querySelector('#address_section');
            if (executed && addressSection) { // <- Added addressSection check
                addressSection.insertAdjacentHTML('afterbegin', `
                    <span class="section-link" id="location"></span> 
                    <div class="row">
        <div class="col-md-8" style="padding-left: 0;"><h2 class="head text-capitalize">${h1tag} Location Map and Connectivity</h2></div>
        <div class="col-md-4"><button class="btn btn-info micro-form-btn enqModal effetMoveGradient effectScale float-lg-right mx-sm-auto  d-none d-lg-block" data-form="lg" data-title="Get Directions" data-btn="Send Now" data-enquiry="Get Directions" data-redirect="floorplan" data-toggle="modal" data-target="#enqModal">Get Directions</button></div></div>
                    <div class="row mb-3"> 
                        <div class="col-md-5 col-12 lmap-div text-center location padding0"> 
                            <a href="#" class="text-decoration-none enqModal" aria-label="Download Location Map" data-form="lg" data-title="Download Location Map" data-btn="Download now" data-enquiry="View Location Map" data-toggle="modal" data-target="#enqModal"> 
                                <div class="at-property-item mb-2"> 
                                    <div class="at-property-img location-map lazyloaded" data-expand="-1"> 
                                        <img alt="Location Map" class="shadow-sm border border-grey lazyautosizes ls-is-cached lazyloaded ls-inview" src="./assets/img/locationmap.webp"> 
                                        <div class="at-property-overlayer"></div> 
                                        <span class="at-property-btn">Download Location Map</span> 
                                    </div> 
                                </div> 
                            </a> 
                        </div> 
                        <div class="col-md-7 col-12 padding0 p-left-10">
                        <div class="row"> 
                        <div class="col loc-pointer loc-pointer-first"><div class="loc-text"><i class="mi mi-loc-list-2 color-primary loc-icon"></i> <span>Dwarka Expressway  </span> </div><span class="text-right">20  mins</span></div> 
                        <div class="col loc-pointer"><div class="loc-text"><i class="mi mi-loc-list-2 color-primary loc-icon"></i> <span>Sohna Gurugram Road </span></div> <span class="text-right"> 10  mins</span></div> 
                        <div class="col loc-pointer"><div class="loc-text"><i class="mi mi-loc-list-2 color-primary loc-icon"></i> <span>Indira Gandhi International Airport</span> </div><span class="text-right">40 mins</span></div> 
                    </div> 
                        </div>
                    </div> 
                    <div class="col-12 text-center">
        <p></p>
            <button class="btn btn-info micro-form-btn enqModal effetMoveGradient effectScale float-lg-right mx-sm-auto d-lg-none" data-form="lg" data-title="Get Directions" data-btn="Send Now" data-enquiry="Get Directions" data-redirect="floorplan" data-toggle="modal" data-target="#enqModal">Get Directions</button>
        </div>
                `);
                   executed = false;
               }
            };
        </script>
       <!-- Onload start --> 
        <script src="assets/js/jquery.min.js"></script> 
        <script type="text/javascript">
        $(document).ready(function(){
            $("input[name='modal_my_mobile2']").focusout(function(){
                $(".mobileconcat").val('+'+$("#country_code").val()+$(this).val()); 
            });
            
            // on country name field change
            $("select[name='country_name']").focusout(function(){
                $(".mobileconcat").val('+'+$("#country_code").val()+$(this).siblings("input[name='modal_my_mobile2']").val()); 
            });
            $('select.my_country_name').change(function() {
                var capacityValue = $("option:selected", this).data('contry_code');
                    $('.operations-supplierCapacity').val(capacityValue);
            });
            // Split Form Name into First name and Last Name
            $("input[name='fname']").focusout(function(){
                var name = $(this).val();
                var first_name = name.substr(0,name.indexOf(' '));
                var last_name = name.substr(name.indexOf(' ')+1);
                $("input[name='first_name']").val(first_name);
                $("input[name='last_name']").val(last_name);
            });
        });  
        </script>
        <!-- Onload end --> 
       
    <script>
        var c, a = window.location.pathname,
d = a.substring(a.lastIndexOf("/") + 1);
if (d !== "thank-you.php") {
    
    function addEvent(obj, evt, fn) {
        if (obj.addEventListener) {
            obj.addEventListener(evt, fn, false);
        } else if (obj.attachEvent) {
            obj.attachEvent("on" + evt, fn);
        }
    }
    
    addEvent(document, 'mouseout', function(evt) {
        
        let windowHeight = window.innerHeight;
        if (evt.toElement == null && evt.relatedTarget == null && (evt.y < 0 || evt.y > windowHeight)) {
            
            if(sessionStorage["PopupShown"] != 'yes' && $('#enqModal').css('display') == 'none'){ 
                
                sessionStorage["PopupShown"] = 'yes';
               $("#enqModal .modal-head").removeClass("d-none");
                    $("#enqModal .modal-call-btn").addClass("d-none");
                    $("#enqModal .modal-title").text("Virtual Site Visit"),
                    $("#enqModal .micro-form-btn").text("Start Tour"),
                    $("#enqModal #enquiredfor").val("Virtual Tour Exit intent popup"),
                    $('#enqModal').modal('show');
    
            }
        };
        
    });
    
    sessionStorage.clear();
    var available;
    var percentage_of_page;
    var half_screen;
    var height;
        $(window).scroll(function (e) {
            available = $(document).height();
            percentage_of_page = 0.5;
            half_screen = available * percentage_of_page;
            height = $(window).scrollTop();
            // alert(height)
            if ( height > half_screen ) {
                if(sessionStorage["PopupShown1"] != 'yes1' && $('#enqModal').css('display') == 'none'){
                     sessionStorage["PopupShown1"] = 'yes1';
                     sessionStorage["PopupShown"] = 'yes';
                     $("#enqModal .modal-head").removeClass("d-none");
                    $("#enqModal .modal-call-btn").addClass("d-none");
                    $("#enqModal .modal-title").text("Virtual Site Visit"),
                    $("#enqModal .micro-form-btn").text("Start Tour"),
                    $("#enqModal #enquiredfor").val("Virtual Tour Exit intent popup on scroll"),
                    $('#enqModal').modal('show');
                }
            } else {
                $('.lightbox').hide();
            }
        });
}
 </script>
 
<script src="./assets/js/chatv25.js"></script>

<script type="text/javascript">
    var chatbotApiInput = {
        home_url: "https://www.birlassector71.com/birla-estate-sector71-gurugram/privacy-policy.php",
        gclid: "",
        utm_source: "",
        utm_medium: "",
        utm_campaign: "",
        utm_term: "",
        utm_physical_location: "",
        utm_tragetid: "",
        utm_target: "",
        utm_placement: "",
        utm_adposition: "",
        fbclid: "",
        builder: " Birla Estates",
        project: "Birla Sector 71 Gurgaon ",
        source: "Microsite Chat Icon",
        lead_source: "chatbot",
        ip: "211.132.176.145",
        imagepath :"/assets/img/chatbot/",
        leadcoversion: "hbpushleads",
        desktoptimer: 10000,
        mobiletimer: 10000,
        device: "Desktop",
    };
    var timer = 0;
</script>    


<script>
    $('form#pardotForm').submit(function(e){
    $(this).children('button[type=submit]').attr('disabled', 'disabled');
    $(this).children('input[type=submit]').attr('disabled', 'disabled');
});

</script>
<script>
const fpPromise = import('https://fpjscdn.net/v3/rmevazJvk6HdBPJpRXuX')
   .then(FingerprintJS => FingerprintJS.load({
     region: "ap"
   }))
  
   function bindFormSubmit() {
   $('form#pardotForm').off('submit').on('submit', function (e) {
       e.preventDefault();


       var $form = $(this);
       var $submitBtn = $form.find('button[type="submit"], input[type="submit"]');
       var $errorSpan = $form.find('.errorMessage');


       // Disable the submit button to prevent multiple clicks
       $submitBtn.prop('disabled', true);


       // Clear any previous error and timeout
       $errorSpan.text('');
       clearTimeout($errorSpan.data('timeoutId'));


       $.ajax({
           url: 'ipcheck.php',
           type: 'GET',
           dataType: 'json',
           success: function (data) {
               if (data.status) {
                   // Get FingerprintJS visitorId
                   fpPromise
                       .then(fp => fp.get())
                       .then(result => {
                           const deviceId = result.visitorId || ('fallback-' + Date.now());


                           // 1. Insert or update the hidden input
                           let $deviceIdField = $form.find('input[name="device_id"]');
                           if ($deviceIdField.length === 0) {
                               $form.append('<input type="hidden" name="device_id" value="">');
                               $deviceIdField = $form.find('input[name="device_id"]');
                           }
                           $deviceIdField.val(deviceId);


                           console.log('Device ID:', deviceId);


                           // 2. Submit the form safely
                           $form.off('submit'); // remove handler to prevent recursion
                           $form.submit();
                       })
                       .catch(err => {
                           console.error('FingerprintJS error:', err);


                           // fallback device ID if visitorId fails
                           const deviceId = 'fallback-' + Date.now();


                           let $deviceIdField = $form.find('input[name="device_id"]');
                           if ($deviceIdField.length === 0) {
                               $form.append('<input type="hidden" name="device_id" value="">');
                               $deviceIdField = $form.find('input[name="device_id"]');
                           }
                           $deviceIdField.val(deviceId);


                           // Submit the form anyway
                           $form.off('submit');
                           $form.submit();
                       });
               } else {
                   $errorSpan.text(data.message);


                   var timeoutId = setTimeout(function () {
                       $errorSpan.fadeOut(400, function () {
                           $(this).text('').show();
                       });
                   }, 5000);
                   $errorSpan.data('timeoutId', timeoutId);


                   // Re-enable the submit button for retry
                   $submitBtn.prop('disabled', false);
               }
           },
           error: function () {
               $errorSpan.text('An unexpected error occurred.');


               var timeoutId = setTimeout(function () {
                   $errorSpan.fadeOut(400, function () {
                       $(this).text('').show();
                   });
               }, 5000);
               $errorSpan.data('timeoutId', timeoutId);


               // Re-enable the submit button on error
               $submitBtn.prop('disabled', false);
           }
       });
   });
}


// Bind when document is ready
$(document).ready(function() {
    bindFormSubmit();
});

// Also bind when coming back from bfcache
$(window).on('pageshow', function(event) {
    if (event.originalEvent.persisted) {
        bindFormSubmit();
    }
});




</script>

<script>
$(document).ready(function() {
  $('#blockimg').removeClass('blockimg');
});
</script>


<script defer src="./assets/js/app1_min.js"></script>
</body>
</html>